// Icon set used by the shell and components.
// TODO: implement.
export {};
