// AppShell: sidebar with role navigation, badges and sign out, plus the page header (SRS 3.1.1).
// TODO: implement.
export {};
