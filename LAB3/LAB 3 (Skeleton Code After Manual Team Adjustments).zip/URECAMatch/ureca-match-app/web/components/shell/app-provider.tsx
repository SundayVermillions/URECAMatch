// AppProvider: the signed-in user, the round phase and unread counts for every screen.
// TODO: implement.
export {};
