// PdfViewer: shows a document inside the browser through a signed link (REQ-VRANK-3).
// TODO: implement.
export {};
