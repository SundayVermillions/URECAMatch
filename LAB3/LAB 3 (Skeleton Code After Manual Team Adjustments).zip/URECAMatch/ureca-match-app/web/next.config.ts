// Next.js configuration. TODO: options.
export default {};
