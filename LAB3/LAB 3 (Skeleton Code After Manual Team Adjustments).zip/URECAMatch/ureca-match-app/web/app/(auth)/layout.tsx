// (auth) layout: centred layout for the sign-in screens.
export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
