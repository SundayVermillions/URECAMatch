// CreateAccountPage <<boundary>>: registration form with role choice; calls AuthController.register.
import type { ApiClient } from "@/lib/api/client";

export default function CreateAccountPage() {
  // TODO: load data through ApiClient and render the screen as specified in the dialog map.
  return null;
}
