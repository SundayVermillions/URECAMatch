// SignInPage <<boundary>>: sign-in form; calls ApiClient.signIn(email, password).
import type { ApiClient } from "@/lib/api/client";

export default function SignInPage() {
  // TODO: load data through ApiClient and render the screen as specified in the dialog map.
  return null;
}
