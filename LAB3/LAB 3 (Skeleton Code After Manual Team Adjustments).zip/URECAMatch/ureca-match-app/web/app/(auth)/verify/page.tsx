// EmailVerificationPage <<boundary>>: 6-digit code entry and resend; calls AuthController.verify / resend.
import type { ApiClient } from "@/lib/api/client";

export default function EmailVerificationPage() {
  // TODO: load data through ApiClient and render the screen as specified in the dialog map.
  return null;
}
