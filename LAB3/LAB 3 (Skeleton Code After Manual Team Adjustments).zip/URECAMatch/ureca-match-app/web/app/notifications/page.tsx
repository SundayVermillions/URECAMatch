// NotificationPage <<boundary>>: own notifications, newest first; DashboardController.myNotifications / markRead.
import type { ApiClient } from "@/lib/api/client";

export default function NotificationPage() {
  // TODO: load data through ApiClient and render the screen as specified in the dialog map.
  return null;
}
