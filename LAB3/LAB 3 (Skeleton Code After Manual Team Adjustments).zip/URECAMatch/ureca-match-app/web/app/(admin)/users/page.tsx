// ManageUsersPage <<boundary>>: user list; UserAccountController.
import type { ApiClient } from "@/lib/api/client";

export default function ManageUsersPage() {
  // TODO: load data through ApiClient and render the screen as specified in the dialog map.
  return null;
}
