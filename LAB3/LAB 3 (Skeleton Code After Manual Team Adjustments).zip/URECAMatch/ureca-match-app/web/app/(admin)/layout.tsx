// (admin) layout: AppShell for Admins.
export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
