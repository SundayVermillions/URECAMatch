// AdminDashboardPage <<boundary>>: counts and alerts; DashboardController.adminDashboard.
import type { ApiClient } from "@/lib/api/client";

export default function AdminDashboardPage() {
  // TODO: load data through ApiClient and render the screen as specified in the dialog map.
  return null;
}
