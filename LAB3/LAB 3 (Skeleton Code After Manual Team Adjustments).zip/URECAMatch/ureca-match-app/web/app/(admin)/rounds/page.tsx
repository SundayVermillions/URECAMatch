// MatchingRoundsPage <<boundary>>: cycle and rounds; CycleController, MatchingController.execute.
import type { ApiClient } from "@/lib/api/client";

export default function MatchingRoundsPage() {
  // TODO: load data through ApiClient and render the screen as specified in the dialog map.
  return null;
}
