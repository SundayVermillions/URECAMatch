// (student) layout: AppShell for Students; profile gate until the profile is complete.
export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
