// MyApplicationPage <<boundary>>: applications, ranking, proposals and the match offer; ApplicationController, MatchingController.acceptOffer / declineOffer.
import type { ApiClient } from "@/lib/api/client";

export default function MyApplicationPage() {
  // TODO: load data through ApiClient and render the screen as specified in the dialog map.
  return null;
}
