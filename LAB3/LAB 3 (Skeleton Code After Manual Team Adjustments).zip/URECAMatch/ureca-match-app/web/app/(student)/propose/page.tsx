// ProposeProjectPage <<boundary>>: self-proposal form and supervisor picker; ProposalController.propose.
import type { ApiClient } from "@/lib/api/client";

export default function ProposeProjectPage() {
  // TODO: load data through ApiClient and render the screen as specified in the dialog map.
  return null;
}
