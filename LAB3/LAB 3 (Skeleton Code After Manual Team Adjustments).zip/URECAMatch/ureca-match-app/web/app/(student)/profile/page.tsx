// MyProfilePage <<boundary>>: profile form; in complete mode (?complete=1) it is CompleteProfilePage, shown until the profile is complete.
import type { ApiClient } from "@/lib/api/client";

export default function MyProfilePage() {
  // TODO: load data through ApiClient and render the screen as specified in the dialog map.
  return null;
}
