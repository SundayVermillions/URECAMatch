// BrowseProjectPage <<boundary>>: search and filter ProjectListing; ListingController.browse.
import type { ApiClient } from "@/lib/api/client";

export default function BrowseProjectPage() {
  // TODO: load data through ApiClient and render the screen as specified in the dialog map.
  return null;
}
