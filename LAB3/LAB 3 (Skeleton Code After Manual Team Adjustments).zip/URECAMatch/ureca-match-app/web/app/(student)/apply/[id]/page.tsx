// ApplyProjectPage <<boundary>>: statement and documents; ApplicationController.apply.
import type { ApiClient } from "@/lib/api/client";

export default function ApplyProjectPage() {
  // TODO: load data through ApiClient and render the screen as specified in the dialog map.
  return null;
}
