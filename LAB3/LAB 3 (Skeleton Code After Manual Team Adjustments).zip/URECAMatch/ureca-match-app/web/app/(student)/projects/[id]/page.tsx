// ProjectDetailPage <<boundary>>: one ProjectListing; ListingController.detail.
import type { ApiClient } from "@/lib/api/client";

export default function ProjectDetailPage() {
  // TODO: load data through ApiClient and render the screen as specified in the dialog map.
  return null;
}
