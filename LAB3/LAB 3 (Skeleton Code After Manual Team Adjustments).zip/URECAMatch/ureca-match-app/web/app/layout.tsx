// Root layout: fonts, global styles and the app provider (current user).
export default function RootLayout({ children }: { children: React.ReactNode }) {
  // TODO: <html lang="en"> with the app provider around children
  return children;
}
