// (supervisor) layout: AppShell for Project Supervisors.
export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
