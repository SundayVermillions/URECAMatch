// EditProjectPage <<boundary>>: edit ProjectListing; ListingController.update.
import type { ApiClient } from "@/lib/api/client";

export default function EditProjectPage() {
  // TODO: load data through ApiClient and render the screen as specified in the dialog map.
  return null;
}
