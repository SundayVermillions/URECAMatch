// CreateProjectPage <<boundary>>: new ProjectListing; ListingController.create / cover.
import type { ApiClient } from "@/lib/api/client";

export default function CreateProjectPage() {
  // TODO: load data through ApiClient and render the screen as specified in the dialog map.
  return null;
}
