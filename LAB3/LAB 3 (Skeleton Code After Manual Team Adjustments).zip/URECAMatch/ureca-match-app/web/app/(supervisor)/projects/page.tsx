// SupervisorProjectsPage <<boundary>>: own listings; ListingController.myListings / close.
import type { ApiClient } from "@/lib/api/client";

export default function SupervisorProjectsPage() {
  // TODO: load data through ApiClient and render the screen as specified in the dialog map.
  return null;
}
