// Root: send the user to the home screen of their role, or to sign-in.
export default function Home() {
  return null;
}
