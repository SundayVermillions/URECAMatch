// End-to-end journey across all roles (Playwright): register, apply, rank, match, approve, publish, accept.
