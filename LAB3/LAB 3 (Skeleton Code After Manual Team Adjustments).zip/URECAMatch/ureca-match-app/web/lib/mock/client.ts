// MockClient: implements ApiClient on in-browser seed data, so the whole app runs without a server.
import type { ApiClient } from "../api/client";

export class MockClient implements ApiClient {
  async signIn(email: string, password: string): Promise<unknown> {
    throw new Error("TODO");
  }
}
