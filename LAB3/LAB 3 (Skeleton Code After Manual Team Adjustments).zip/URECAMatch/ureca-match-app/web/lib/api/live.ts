// LiveApiClient: implements ApiClient over HTTPS / REST.
import type { ApiClient } from "./client";

export class LiveClient implements ApiClient {
  async signIn(email: string, password: string): Promise<unknown> {
    throw new Error("TODO");
  }
}
