// Generated from shared/openapi.json by `npm run gen`; never edited by hand.
