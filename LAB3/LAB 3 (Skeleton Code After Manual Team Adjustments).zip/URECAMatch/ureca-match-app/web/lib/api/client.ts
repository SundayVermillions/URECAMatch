// ApiClient <<boundary>>: the only way screens reach the API (Strategy: live or mock), chosen by NEXT_PUBLIC_API_MODE.
export interface ApiClient {
  signIn(email: string, password: string): Promise<unknown>;
  // TODO: one method per API endpoint, typed from types.ts
}

export function getClient(): ApiClient {
  throw new Error("TODO");
}
