// Friendly names for the generated API types. TODO: re-export the types screens use.
