// Browser session: store the token and expire it after 30 minutes of inactivity (REQ-AUTH-3).
