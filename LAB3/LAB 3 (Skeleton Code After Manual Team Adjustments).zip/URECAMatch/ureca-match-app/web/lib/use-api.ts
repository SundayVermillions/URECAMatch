// useApi(): fetch hook that refreshes the session and redirects to sign-in when it expires.
