"""Tests: NFR 5 1 email. TODO: one test per requirement, named test_REQ_<AREA>_<n>_<behaviour>."""


def test_placeholder():
    pass
