"""Tests: REQ PUB 2 and account notify. TODO: one test per requirement, named test_REQ_<AREA>_<n>_<behaviour>."""


def test_placeholder():
    pass
