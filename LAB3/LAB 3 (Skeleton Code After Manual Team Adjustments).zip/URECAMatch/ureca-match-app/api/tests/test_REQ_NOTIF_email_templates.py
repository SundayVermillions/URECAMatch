"""Tests: REQ NOTIF email templates. TODO: one test per requirement, named test_REQ_<AREA>_<n>_<behaviour>."""


def test_placeholder():
    pass
