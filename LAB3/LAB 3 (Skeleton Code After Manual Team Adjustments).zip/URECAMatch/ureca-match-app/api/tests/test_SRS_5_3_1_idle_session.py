"""Tests: SRS 5 3 1 idle session. TODO: one test per requirement, named test_REQ_<AREA>_<n>_<behaviour>."""


def test_placeholder():
    pass
