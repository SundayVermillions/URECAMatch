"""AuthController <<control>>: enforces the rules for its feature; data only through Store."""

from fastapi import APIRouter

from app.deps import current_user, require_role  # noqa: F401
from app.errors import ApiError  # noqa: F401

router = APIRouter(tags=["auth"])


def register(body):  # returns Ok
    raise NotImplementedError

def verify(email, code):  # returns Ok
    raise NotImplementedError

def resend(email):  # returns Ok
    raise NotImplementedError

def sign_in(email, password):  # returns Session
    raise NotImplementedError

def me():  # returns Me
    raise NotImplementedError
