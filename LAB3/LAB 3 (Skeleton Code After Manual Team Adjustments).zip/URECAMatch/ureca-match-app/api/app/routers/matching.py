"""MatchingController <<control>>: enforces the rules for its feature; data only through Store."""

from fastapi import APIRouter

from app.deps import current_user, require_role  # noqa: F401
from app.errors import ApiError  # noqa: F401

router = APIRouter(tags=["matching"])


def execute(roundId):  # returns RoundSummary
    raise NotImplementedError

def summary(roundId):  # returns RoundSummary
    raise NotImplementedError

def matches(roundId, status):  # returns List<MatchResult>
    raise NotImplementedError

def reassign(matchId, listingId, justification):  # returns MatchResult
    raise NotImplementedError

def manual_assign(roundId, studentId, listingId, justification):  # returns MatchResult
    raise NotImplementedError

def publish(roundId):  # returns RoundSummary
    raise NotImplementedError

def audit_log(operation):  # returns List<AuditLogEntry>
    raise NotImplementedError

def approve(matchId, note):  # returns MatchResult
    raise NotImplementedError

def reject(matchId, note):  # returns MatchResult
    raise NotImplementedError

def accept_offer():  # returns MatchResult
    raise NotImplementedError

def decline_offer():  # returns MatchResult
    raise NotImplementedError

def tick():  # returns Ok
    raise NotImplementedError
