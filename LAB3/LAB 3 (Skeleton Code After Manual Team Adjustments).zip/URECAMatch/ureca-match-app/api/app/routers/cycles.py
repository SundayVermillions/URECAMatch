"""CycleController <<control>>: enforces the rules for its feature; data only through Store."""

from fastapi import APIRouter

from app.deps import current_user, require_role  # noqa: F401
from app.errors import ApiError  # noqa: F401

router = APIRouter(tags=["cycles"])


def current_cycle():  # returns ApplicationCycle
    raise NotImplementedError

def list_cycles():  # returns List<ApplicationCycle>
    raise NotImplementedError

def create_cycle(body):  # returns ApplicationCycle
    raise NotImplementedError

def update_cycle(id, body):  # returns ApplicationCycle
    raise NotImplementedError

def set_rounds(id, rounds):  # returns ApplicationCycle
    raise NotImplementedError

def close_cycle(id):  # returns ApplicationCycle
    raise NotImplementedError

def reopen_cycle(id):  # returns ApplicationCycle
    raise NotImplementedError
