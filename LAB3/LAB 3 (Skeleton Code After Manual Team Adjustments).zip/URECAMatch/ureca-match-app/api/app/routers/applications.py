"""ApplicationController <<control>>: enforces the rules for its feature; data only through Store."""

from fastapi import APIRouter

from app.deps import current_user, require_role  # noqa: F401
from app.errors import ApiError  # noqa: F401

router = APIRouter(tags=["applications"])


def mine():  # returns List<Application>
    raise NotImplementedError

def apply(body):  # returns Application
    raise NotImplementedError

def withdraw(id):  # returns Ok
    raise NotImplementedError

def rank(applicationIds):  # returns List<Application>
    raise NotImplementedError
