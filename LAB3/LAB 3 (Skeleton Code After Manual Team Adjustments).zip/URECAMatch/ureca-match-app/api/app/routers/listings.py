"""ListingController <<control>>: enforces the rules for its feature; data only through Store."""

from fastapi import APIRouter

from app.deps import current_user, require_role  # noqa: F401
from app.errors import ApiError  # noqa: F401

router = APIRouter(tags=["listings"])


def browse(q, school, tag, supervisor):  # returns List<ProjectListing>
    raise NotImplementedError

def detail(id):  # returns ProjectListing
    raise NotImplementedError

def supervisors():  # returns List<SupervisorProfile>
    raise NotImplementedError

def my_listings():  # returns List<ProjectListing>
    raise NotImplementedError

def create(body):  # returns ProjectListing
    raise NotImplementedError

def update(id, body):  # returns ProjectListing
    raise NotImplementedError

def close(id):  # returns ProjectListing
    raise NotImplementedError

def cover(id, file):  # returns ProjectListing
    raise NotImplementedError
