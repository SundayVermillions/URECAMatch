"""ProfileController <<control>>: enforces the rules for its feature; data only through Store."""

from fastapi import APIRouter

from app.deps import current_user, require_role  # noqa: F401
from app.errors import ApiError  # noqa: F401

router = APIRouter(tags=["profile"])


def get_profile():  # returns StudentProfile
    raise NotImplementedError

def update_profile(body):  # returns StudentProfile
    raise NotImplementedError

def upload_document(file):  # returns SupportingDocument
    raise NotImplementedError
