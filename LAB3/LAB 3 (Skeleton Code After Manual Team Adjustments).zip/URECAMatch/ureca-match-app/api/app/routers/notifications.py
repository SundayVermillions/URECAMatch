"""DashboardController <<control>>: enforces the rules for its feature; data only through Store."""

from fastapi import APIRouter

from app.deps import current_user, require_role  # noqa: F401
from app.errors import ApiError  # noqa: F401

router = APIRouter(tags=["notifications"])


def my_notifications():  # returns List<Notification>
    raise NotImplementedError

def mark_read(id):  # returns Ok
    raise NotImplementedError

def admin_dashboard():  # returns AdminDashboard
    raise NotImplementedError

def supervisor_dashboard():  # returns SupervisorDashboard
    raise NotImplementedError
