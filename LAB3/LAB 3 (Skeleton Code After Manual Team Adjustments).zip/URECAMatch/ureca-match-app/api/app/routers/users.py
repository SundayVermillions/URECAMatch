"""UserAccountController <<control>>: enforces the rules for its feature; data only through Store."""

from fastapi import APIRouter

from app.deps import current_user, require_role  # noqa: F401
from app.errors import ApiError  # noqa: F401

router = APIRouter(tags=["users"])


def list_users(role, status, query):  # returns List<User>
    raise NotImplementedError

def create_user(body):  # returns User
    raise NotImplementedError

def update_user(id, body):  # returns User
    raise NotImplementedError

def deactivate(id):  # returns Ok
    raise NotImplementedError
