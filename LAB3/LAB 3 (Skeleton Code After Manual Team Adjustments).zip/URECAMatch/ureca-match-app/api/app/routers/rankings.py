"""RankingController <<control>>: enforces the rules for its feature; data only through Store."""

from fastapi import APIRouter

from app.deps import current_user, require_role  # noqa: F401
from app.errors import ApiError  # noqa: F401

router = APIRouter(tags=["rankings"])


def applicants(listingId, filters):  # returns List<Applicant>
    raise NotImplementedError

def applicant(applicationId):  # returns Applicant
    raise NotImplementedError

def get_ranking(listingId):  # returns ApplicantRanking
    raise NotImplementedError

def put_ranking(listingId, applicationIds):  # returns ApplicantRanking
    raise NotImplementedError

def view_document(documentId):  # returns SignedUrl
    raise NotImplementedError
