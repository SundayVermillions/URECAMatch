"""ProposalController <<control>>: enforces the rules for its feature; data only through Store."""

from fastapi import APIRouter

from app.deps import current_user, require_role  # noqa: F401
from app.errors import ApiError  # noqa: F401

router = APIRouter(tags=["proposals"])


def propose(body):  # returns Proposal
    raise NotImplementedError

def my_proposals():  # returns List<Proposal>
    raise NotImplementedError

def incoming():  # returns List<Proposal>
    raise NotImplementedError

def accept(id, note):  # returns Proposal
    raise NotImplementedError

def decline(id, note):  # returns Proposal
    raise NotImplementedError
