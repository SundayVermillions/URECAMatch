"""Generate shared/openapi.json and the seed files from the API and seed data, so the web client types always match."""


def export_contract() -> None:
    raise NotImplementedError
