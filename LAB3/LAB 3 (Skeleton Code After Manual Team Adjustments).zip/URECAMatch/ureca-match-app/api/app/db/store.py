"""Store: the data-access interface (Repository pattern), with its two implementations."""

from typing import Protocol


class Store(Protocol):
    def user(self, id):  # returns User
        ...

    def listing(self, id):  # returns ProjectListing
        ...

    def save_listing(self, listing):  # returns ProjectListing
        ...

    def applications_for(self, studentId, listingId, roundId):  # returns List<Application>
        ...

    def save_applications(self, apps):  # returns void
        ...

    def ranking(self, listingId, roundId):  # returns List<String>
        ...

    def save_notifications(self, items):  # returns void
        ...


class MockStore:
    """Implements Store in memory, for development, tests and demonstrations."""

    def user(self, id):  # returns User
        raise NotImplementedError

    def listing(self, id):  # returns ProjectListing
        raise NotImplementedError

    def save_listing(self, listing):  # returns ProjectListing
        raise NotImplementedError

    def applications_for(self, studentId, listingId, roundId):  # returns List<Application>
        raise NotImplementedError

    def save_applications(self, apps):  # returns void
        raise NotImplementedError

    def ranking(self, listingId, roundId):  # returns List<String>
        raise NotImplementedError

    def save_notifications(self, items):  # returns void
        raise NotImplementedError


class SupabaseStore:
    """Implements Store on Supabase PostgreSQL."""

    def user(self, id):  # returns User
        raise NotImplementedError

    def listing(self, id):  # returns ProjectListing
        raise NotImplementedError

    def save_listing(self, listing):  # returns ProjectListing
        raise NotImplementedError

    def applications_for(self, studentId, listingId, roundId):  # returns List<Application>
        raise NotImplementedError

    def save_applications(self, apps):  # returns void
        raise NotImplementedError

    def ranking(self, listingId, roundId):  # returns List<String>
        raise NotImplementedError

    def save_notifications(self, items):  # returns void
        raise NotImplementedError


def get_store() -> Store:
    raise NotImplementedError
