"""Deterministic demonstration data (users, listings, cycle, rounds) shared by mock mode and the seed files."""


def build() -> dict:
    raise NotImplementedError
