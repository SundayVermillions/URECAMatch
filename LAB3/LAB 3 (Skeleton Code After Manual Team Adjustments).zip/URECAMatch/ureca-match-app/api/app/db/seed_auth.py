"""Create the demonstration accounts in Supabase Auth."""


def seed_auth() -> None:
    raise NotImplementedError
