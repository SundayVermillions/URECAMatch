"""Start-up: create the API application, register one router per controller, configure CORS and settings."""

from fastapi import FastAPI

app = FastAPI(title="URECAMatch API")

# TODO: include the routers (auth, profile, users, listings, proposals, applications, rankings, cycles,
#       matching, notifications) and add CORS for the web client
