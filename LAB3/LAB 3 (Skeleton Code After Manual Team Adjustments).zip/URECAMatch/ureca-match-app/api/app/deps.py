"""Access control: resolve the signed-in user on every request and check the role (SRS 5.3.2)."""

from app.models import Role


def current_user(authorization: str | None):
    raise NotImplementedError


def require_role(*roles: Role):
    raise NotImplementedError
