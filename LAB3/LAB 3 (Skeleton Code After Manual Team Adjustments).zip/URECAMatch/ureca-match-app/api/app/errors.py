"""One error format for every failure: HTTP status, error code, plain-English message, field at fault."""


class ApiError(Exception):
    def __init__(self, status: int, code: str, message: str, field: str | None = None):
        raise NotImplementedError
