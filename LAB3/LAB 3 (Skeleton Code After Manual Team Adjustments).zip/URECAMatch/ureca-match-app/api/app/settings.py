"""Configuration read from the environment: mode, allowed e-mail domains, session length, service keys."""


class Settings:
    api_mode: str = "mock"  # "mock" or "supabase"
    email_domains: tuple[str, ...] = ("e.ntu.edu.sg", "ntu.edu.sg")
    session_minutes: int = 30


def get_settings() -> Settings:
    raise NotImplementedError
