"""Entity models and enumerations: the data every layer exchanges. One class per persistent entity."""

from datetime import datetime
from enum import Enum

from pydantic import BaseModel


class Role(str, Enum):
    student = "student"
    supervisor = "supervisor"
    admin = "admin"

class AccountStatus(str, Enum):
    pending_verification = "pending_verification"
    active = "active"
    inactive = "inactive"

class CycleStatus(str, Enum):
    draft = "draft"
    pre_application = "pre_application"
    in_progress = "in_progress"
    closed = "closed"

class RoundStatus(str, Enum):
    scheduled = "scheduled"
    application_window = "application_window"
    review_window = "review_window"
    awaiting_publication = "awaiting_publication"
    published = "published"
    completed = "completed"

class ListingStatus(str, Enum):
    draft = "draft"
    published = "published"
    closed = "closed"

class ApplicationStatus(str, Enum):
    submitted = "submitted"
    withdrawn = "withdrawn"
    matched = "matched"
    unmatched = "unmatched"

class ProposalStatus(str, Enum):
    submitted = "submitted"
    accepted = "accepted"
    declined = "declined"

class MatchStatus(str, Enum):
    proposed = "proposed"
    approved = "approved"
    rejected = "rejected"
    reassigned = "reassigned"
    published = "published"
    accepted = "accepted"
    declined = "declined"
    timed_out = "timed_out"

class AuditOperation(str, Enum):
    matching_executed = "matching_executed"
    manual_reassignment = "manual_reassignment"
    results_published = "results_published"
    user_updated = "user_updated"
    user_deactivated = "user_deactivated"
    cycle_updated = "cycle_updated"


class User(BaseModel):
    id: str | None = None
    email: str | None = None
    name: str | None = None
    role: Role | None = None
    status: AccountStatus | None = None
    createdAt: datetime | None = None
    lastLoginAt: datetime | None = None
    # association: User 1 -- 0..1 StudentProfile
    # association: User 1 -- 0..1 SupervisorProfile
    # association: User 1 -- 0..* Notification (receives)
    # association: User 1 -- 0..* AuditLogEntry (initiates)


class StudentProfile(BaseModel):
    school: str | None = None
    cgpa: float | None = None
    yearOfStudy: int | None = None
    completedModules: list[str] | None = None
    researchInterests: list[str] | None = None
    profileComplete: bool | None = None
    eligibleForMatching: bool | None = None
    # association: StudentProfile 1 -- 0..* SupportingDocument (owns)
    # association: StudentProfile 1 -- 0..* Application (submits)
    # association: StudentProfile 1 -- 0..* Proposal (proposes)


class SupervisorProfile(BaseModel):
    faculty: str | None = None
    organisation: str | None = None
    # association: SupervisorProfile 1 -- 0..* ProjectListing (offers)
    # association: SupervisorProfile 1 -- 0..* Proposal (reviews)


class VerificationCode(BaseModel):
    email: str | None = None
    code: str | None = None
    expiresAt: datetime | None = None


class SupportingDocument(BaseModel):
    id: str | None = None
    fileName: str | None = None
    fileFormat: str | None = None
    fileSize: int | None = None
    uploadedAt: datetime | None = None
    storagePath: str | None = None


class ProjectListing(BaseModel):
    id: str | None = None
    title: str | None = None
    description: str | None = None
    prerequisites: list[str] | None = None
    topicTags: list[str] | None = None
    availableSlots: int | None = None
    filledSlots: int | None = None
    offeringFaculty: str | None = None
    researchLocation: str | None = None
    coverUrl: str | None = None
    status: ListingStatus | None = None
    createdAt: datetime | None = None
    # association: ProjectListing 1 -- 0..* Application (receives)
    # association: ProjectListing 1 -- 0..* ApplicantRanking (ranked in)


class Application(BaseModel):
    id: str | None = None
    statement: str | None = None
    submittedAt: datetime | None = None
    preferenceRank: int | None = None
    status: ApplicationStatus | None = None
    documentIds: list[str] | None = None
    # association: MatchingRound 1 -- 0..* Application
    # association: Application 0..* -- 0..* SupportingDocument (attaches)


class Proposal(BaseModel):
    id: str | None = None
    title: str | None = None
    description: str | None = None
    researchInterests: list[str] | None = None
    statement: str | None = None
    status: ProposalStatus | None = None
    submittedAt: datetime | None = None
    decidedAt: datetime | None = None
    documentIds: list[str] | None = None
    # association: Proposal 1 -- 0..1 ProjectListing (creates when accepted)


class ApplicantRanking(BaseModel):
    applicationIds: list[str] | None = None
    submittedAt: datetime | None = None
    # association: MatchingRound 1 -- 0..* ApplicantRanking


class ApplicationCycle(BaseModel):
    id: str | None = None
    academicYear: str | None = None
    openingDate: datetime | None = None
    closingDate: datetime | None = None
    preApplicationDays: int | None = None
    status: CycleStatus | None = None
    # association: ApplicationCycle 1 *-- 1..3 MatchingRound (comprises, composition)


class MatchingRound(BaseModel):
    id: str | None = None
    number: int | None = None
    applicationStart: datetime | None = None
    applicationEnd: datetime | None = None
    reviewStart: datetime | None = None
    reviewEnd: datetime | None = None
    status: RoundStatus | None = None
    executedAt: datetime | None = None
    publishedAt: datetime | None = None
    # association: MatchingRound 1 -- 0..* MatchResult (produces)


class MatchResult(BaseModel):
    id: str | None = None
    status: MatchStatus | None = None
    preferenceRank: int | None = None
    supervisorDecidedAt: datetime | None = None
    publishedAt: datetime | None = None
    offerExpiresAt: datetime | None = None
    studentRespondedAt: datetime | None = None
    originalListingId: str | None = None
    justification: str | None = None
    # association: MatchResult 0..* -- 1 StudentProfile (allocates)
    # association: MatchResult 0..* -- 1 ProjectListing (fills)


class Notification(BaseModel):
    id: str | None = None
    event: NotificationEvent | None = None
    title: str | None = None
    message: str | None = None
    createdAt: datetime | None = None
    read: bool | None = None
    link: str | None = None


class AuditLogEntry(BaseModel):
    id: str | None = None
    operation: AuditOperation | None = None
    timestamp: datetime | None = None
    affectedRecords: list[str] | None = None
    note: str | None = None
