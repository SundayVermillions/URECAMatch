"""StorageService <<control>> service."""

def put(bucket, path, data):  # returns String
    raise NotImplementedError

def signed_url(bucket, path, minutes):  # returns String
    raise NotImplementedError
