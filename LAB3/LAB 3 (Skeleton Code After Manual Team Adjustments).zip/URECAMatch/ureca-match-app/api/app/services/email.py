"""EmailService <<control>> service."""

def send_for(notifications):  # returns int
    raise NotImplementedError
