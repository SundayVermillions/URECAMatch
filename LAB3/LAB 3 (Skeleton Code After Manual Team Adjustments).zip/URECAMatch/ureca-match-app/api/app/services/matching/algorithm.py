"""MatchingAlgorithm <<control>> service."""

def match(students, listings):  # returns MatchOutcome
    raise NotImplementedError

# note from diagram: student-proposing deferred acceptance with capacities; pure function, no I/O
