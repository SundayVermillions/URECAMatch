"""WindowService <<control>> service."""

def phase(cycle, now):  # returns Phase
    raise NotImplementedError

def current_round(cycle, now):  # returns MatchingRound
    raise NotImplementedError

def in_application_window(cycle, now):  # returns bool
    raise NotImplementedError

def in_review_window(cycle, now):  # returns bool
    raise NotImplementedError
