"""AuditService <<control>> service."""

def audit(actor, operation, affected, note):  # returns AuditLogEntry
    raise NotImplementedError
