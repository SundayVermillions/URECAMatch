"""NotificationService <<control>> service."""

def notify(userIds, event, title, message, link):  # returns List<Notification>
    raise NotImplementedError

# depends on EmailService
