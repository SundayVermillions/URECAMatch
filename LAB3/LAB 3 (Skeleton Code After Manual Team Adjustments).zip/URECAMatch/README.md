# URECAMatch: skeleton after critique (Lab 3, 3.4)

This skeleton is the AI-generated skeleton from 3.3.3 (lab3-ai-generated-skeleton.zip), revised by hand after
our critique in the Lab 3 report (section 4). Declarations and imports are sketched out; every body is unimplemented.

Changes from the AI skeleton:
1. Declarations and imports added for every class, function, page and the API client (manual 3.4.1).
2. Cross-cutting concerns added: settings.py, deps.py (current user and role check), errors.py.
3. Database schema, policies and seed placeholders added (supabase/).
4. Shared layout and component library added (web/app/layout.tsx, web/components/).
5. CI workflow and the generated API contract added (.github/workflows/ci.yml, shared/openapi.json, db/export.py).
6. CompleteProfilePage and MyProfilePage merged into one profile screen with a "complete" mode.
7. Tests named and grouped by requirement area, as in the repository.

Stereotype to folder: boundary = web/app, web/components, web/lib/api; control = api/app/routers (one per
controller) and api/app/services; entity = api/app/models and supabase/schema.sql; data access = api/app/db/store.py.
