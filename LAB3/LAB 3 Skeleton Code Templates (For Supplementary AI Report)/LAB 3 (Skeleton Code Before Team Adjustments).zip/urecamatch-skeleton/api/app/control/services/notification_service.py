# Purpose: NotificationService <<control>> service.
# TODO: notify(userIds, event, title, message, link): List<Notification>
# TODO: depends on EmailService
