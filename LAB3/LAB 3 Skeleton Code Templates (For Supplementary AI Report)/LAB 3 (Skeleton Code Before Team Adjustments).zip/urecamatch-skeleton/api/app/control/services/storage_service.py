# Purpose: StorageService <<control>> service.
# TODO: interface: put(bucket, path, data): String
# TODO: interface: signedUrl(bucket, path, minutes): String
