# Purpose: MatchingAlgorithm <<control>> service.
# TODO: match(students: List<StudentPrefs>, listings: List<ListingPrefs>): MatchOutcome
# TODO: note from diagram: student-proposing deferred acceptance with capacities; pure function, no I/O
