# Purpose: EmailService <<control>> service.
# TODO: sendFor(notifications): int
