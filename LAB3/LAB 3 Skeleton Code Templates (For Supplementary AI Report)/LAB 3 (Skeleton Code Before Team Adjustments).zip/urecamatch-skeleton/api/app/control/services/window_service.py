# Purpose: WindowService <<control>> service.
# TODO: phase(cycle, now): Phase
# TODO: currentRound(cycle, now): MatchingRound
# TODO: inApplicationWindow(cycle, now): bool
# TODO: inReviewWindow(cycle, now): bool
