# Purpose: ApplicationController <<control>>.
# TODO: mine(): List<Application>
# TODO: apply(body): Application
# TODO: withdraw(id): Ok
# TODO: rank(applicationIds): List<Application>
# TODO: depend on Store for data access, never on the database directly.
