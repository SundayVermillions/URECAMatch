# Purpose: MatchingController <<control>>.
# TODO: execute(roundId): RoundSummary
# TODO: summary(roundId): RoundSummary
# TODO: matches(roundId, status): List<MatchResult>
# TODO: reassign(matchId, listingId, justification): MatchResult
# TODO: manualAssign(roundId, studentId, listingId, justification): MatchResult
# TODO: publish(roundId): RoundSummary
# TODO: auditLog(operation): List<AuditLogEntry>
# TODO: approve(matchId, note): MatchResult
# TODO: reject(matchId, note): MatchResult
# TODO: acceptOffer(): MatchResult
# TODO: declineOffer(): MatchResult
# TODO: tick(): Ok
# TODO: depend on Store for data access, never on the database directly.
