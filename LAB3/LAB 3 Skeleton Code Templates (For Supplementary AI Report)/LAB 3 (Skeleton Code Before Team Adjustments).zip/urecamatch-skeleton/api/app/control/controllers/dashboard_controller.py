# Purpose: DashboardController <<control>>.
# TODO: myNotifications(): List<Notification>
# TODO: markRead(id): Ok
# TODO: adminDashboard(): AdminDashboard
# TODO: supervisorDashboard(): SupervisorDashboard
# TODO: depend on Store for data access, never on the database directly.
