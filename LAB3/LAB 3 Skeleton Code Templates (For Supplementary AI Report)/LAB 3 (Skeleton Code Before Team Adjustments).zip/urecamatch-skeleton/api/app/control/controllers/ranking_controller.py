# Purpose: RankingController <<control>>.
# TODO: applicants(listingId, filters): List<Applicant>
# TODO: applicant(applicationId): Applicant
# TODO: getRanking(listingId): ApplicantRanking
# TODO: putRanking(listingId, applicationIds): ApplicantRanking
# TODO: viewDocument(documentId): SignedUrl
# TODO: depend on Store for data access, never on the database directly.
