# Purpose: UserAccountController <<control>>.
# TODO: listUsers(role, status, query): List<User>
# TODO: createUser(body): User
# TODO: updateUser(id, body): User
# TODO: deactivate(id): Ok
# TODO: depend on Store for data access, never on the database directly.
