# Purpose: AuthController <<control>>.
# TODO: register(body): Ok
# TODO: verify(email, code): Ok
# TODO: resend(email): Ok
# TODO: signIn(email, password): Session
# TODO: me(): Me
# TODO: depend on Store for data access, never on the database directly.
