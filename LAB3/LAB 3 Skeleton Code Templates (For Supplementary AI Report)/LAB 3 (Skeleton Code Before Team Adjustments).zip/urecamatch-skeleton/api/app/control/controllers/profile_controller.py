# Purpose: ProfileController <<control>>.
# TODO: getProfile(): StudentProfile
# TODO: updateProfile(body): StudentProfile
# TODO: uploadDocument(file): SupportingDocument
# TODO: depend on Store for data access, never on the database directly.
