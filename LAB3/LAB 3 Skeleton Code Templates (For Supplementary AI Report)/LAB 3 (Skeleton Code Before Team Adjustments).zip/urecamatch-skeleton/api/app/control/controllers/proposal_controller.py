# Purpose: ProposalController <<control>>.
# TODO: propose(body): Proposal
# TODO: myProposals(): List<Proposal>
# TODO: incoming(): List<Proposal>
# TODO: accept(id, note): Proposal
# TODO: decline(id, note): Proposal
# TODO: depend on Store for data access, never on the database directly.
