# Purpose: ListingController <<control>>.
# TODO: browse(q, school, tag, supervisor): List<ProjectListing>
# TODO: detail(id): ProjectListing
# TODO: supervisors(): List<SupervisorProfile>
# TODO: myListings(): List<ProjectListing>
# TODO: create(body): ProjectListing
# TODO: update(id, body): ProjectListing
# TODO: close(id): ProjectListing
# TODO: cover(id, file): ProjectListing
# TODO: depend on Store for data access, never on the database directly.
