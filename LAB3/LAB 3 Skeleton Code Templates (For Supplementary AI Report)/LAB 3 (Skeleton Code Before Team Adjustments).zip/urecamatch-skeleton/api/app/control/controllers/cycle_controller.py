# Purpose: CycleController <<control>>.
# TODO: currentCycle(): ApplicationCycle
# TODO: listCycles(): List<ApplicationCycle>
# TODO: createCycle(body): ApplicationCycle
# TODO: updateCycle(id, body): ApplicationCycle
# TODO: setRounds(id, rounds): ApplicationCycle
# TODO: closeCycle(id): ApplicationCycle
# TODO: reopenCycle(id): ApplicationCycle
# TODO: depend on Store for data access, never on the database directly.
