# Purpose: AppStartup <<control>>, the start-up class.
# TODO: main(): create the app, register one router per controller, configure CORS and settings.
