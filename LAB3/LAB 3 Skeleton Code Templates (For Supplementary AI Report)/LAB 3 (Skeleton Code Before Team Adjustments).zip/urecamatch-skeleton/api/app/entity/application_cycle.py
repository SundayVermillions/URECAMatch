# Purpose: ApplicationCycle <<entity>>, persistent data.
# TODO: attribute id: String
# TODO: attribute academicYear: String
# TODO: attribute openingDate: DateTime
# TODO: attribute closingDate: DateTime
# TODO: attribute preApplicationDays: Integer
# TODO: attribute status: CycleStatus
# TODO: association ApplicationCycle 1 *-- 1..3 MatchingRound (comprises, composition)
