# Purpose: User <<entity>>, persistent data.
# TODO: attribute id: String
# TODO: attribute email: String
# TODO: attribute name: String
# TODO: attribute role: Role
# TODO: attribute status: AccountStatus
# TODO: attribute createdAt: DateTime
# TODO: attribute lastLoginAt: DateTime
# TODO: association User 1 -- 0..1 StudentProfile
# TODO: association User 1 -- 0..1 SupervisorProfile
# TODO: association User 1 -- 0..* Notification (receives)
# TODO: association User 1 -- 0..* AuditLogEntry (initiates)
