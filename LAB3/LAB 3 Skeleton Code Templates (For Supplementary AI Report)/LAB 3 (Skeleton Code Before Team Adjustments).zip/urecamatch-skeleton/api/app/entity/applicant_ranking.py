# Purpose: ApplicantRanking <<entity>>, persistent data.
# TODO: attribute applicationIds: List<String>
# TODO: attribute submittedAt: DateTime
# TODO: association MatchingRound 1 -- 0..* ApplicantRanking
