# Purpose: enumerations used by the entity classes.
# TODO: enum Role: student, supervisor, admin
# TODO: enum AccountStatus: pending_verification, active, inactive
# TODO: enum CycleStatus: draft, pre_application, in_progress, closed
# TODO: enum RoundStatus: scheduled, application_window, review_window, awaiting_publication, published, completed
# TODO: enum ListingStatus: draft, published, closed
# TODO: enum ApplicationStatus: submitted, withdrawn, matched, unmatched
# TODO: enum ProposalStatus: submitted, accepted, declined
# TODO: enum MatchStatus: proposed, approved, rejected, reassigned, published, accepted, declined, timed_out
# TODO: enum AuditOperation: matching_executed, manual_reassignment, results_published, user_updated, user_deactivated, cycle_updated
