# Purpose: AuditLogEntry <<entity>>, persistent data.
# TODO: attribute id: String
# TODO: attribute operation: AuditOperation
# TODO: attribute timestamp: DateTime
# TODO: attribute affectedRecords: List<String>
# TODO: attribute note: String
