# Purpose: MatchResult <<entity>>, persistent data.
# TODO: attribute id: String
# TODO: attribute status: MatchStatus
# TODO: attribute preferenceRank: Integer
# TODO: attribute supervisorDecidedAt: DateTime
# TODO: attribute publishedAt: DateTime
# TODO: attribute offerExpiresAt: DateTime
# TODO: attribute studentRespondedAt: DateTime
# TODO: attribute originalListingId: String
# TODO: attribute justification: String
# TODO: association MatchResult 0..* -- 1 StudentProfile (allocates)
# TODO: association MatchResult 0..* -- 1 ProjectListing (fills)
