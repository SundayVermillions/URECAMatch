# Purpose: Notification <<entity>>, persistent data.
# TODO: attribute id: String
# TODO: attribute event: NotificationEvent
# TODO: attribute title: String
# TODO: attribute message: String
# TODO: attribute createdAt: DateTime
# TODO: attribute read: Boolean
# TODO: attribute link: String
