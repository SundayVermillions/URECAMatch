# Purpose: Application <<entity>>, persistent data.
# TODO: attribute id: String
# TODO: attribute statement: String
# TODO: attribute submittedAt: DateTime
# TODO: attribute preferenceRank: Integer
# TODO: attribute status: ApplicationStatus
# TODO: attribute documentIds: List<String>
# TODO: association MatchingRound 1 -- 0..* Application
# TODO: association Application 0..* -- 0..* SupportingDocument (attaches)
