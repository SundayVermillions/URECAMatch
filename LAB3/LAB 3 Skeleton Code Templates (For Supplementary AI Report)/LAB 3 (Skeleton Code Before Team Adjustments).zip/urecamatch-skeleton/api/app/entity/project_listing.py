# Purpose: ProjectListing <<entity>>, persistent data.
# TODO: attribute id: String
# TODO: attribute title: String
# TODO: attribute description: String
# TODO: attribute prerequisites: List<String>
# TODO: attribute topicTags: List<String>
# TODO: attribute availableSlots: Integer
# TODO: attribute filledSlots: Integer
# TODO: attribute offeringFaculty: String
# TODO: attribute researchLocation: String
# TODO: attribute coverUrl: String
# TODO: attribute status: ListingStatus
# TODO: attribute createdAt: DateTime
# TODO: association ProjectListing 1 -- 0..* Application (receives)
# TODO: association ProjectListing 1 -- 0..* ApplicantRanking (ranked in)
