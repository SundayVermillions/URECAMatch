# Purpose: StudentProfile <<entity>>, persistent data.
# TODO: attribute school: String
# TODO: attribute cgpa: Float
# TODO: attribute yearOfStudy: Integer
# TODO: attribute completedModules: List<String>
# TODO: attribute researchInterests: List<String>
# TODO: attribute profileComplete: Boolean
# TODO: attribute eligibleForMatching: Boolean
# TODO: association StudentProfile 1 -- 0..* SupportingDocument (owns)
# TODO: association StudentProfile 1 -- 0..* Application (submits)
# TODO: association StudentProfile 1 -- 0..* Proposal (proposes)
