# Purpose: VerificationCode <<entity>>, persistent data.
# TODO: attribute email: String
# TODO: attribute code: String
# TODO: attribute expiresAt: DateTime
