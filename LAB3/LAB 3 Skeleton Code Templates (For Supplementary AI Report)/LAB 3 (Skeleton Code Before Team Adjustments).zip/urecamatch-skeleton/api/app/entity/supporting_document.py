# Purpose: SupportingDocument <<entity>>, persistent data.
# TODO: attribute id: String
# TODO: attribute fileName: String
# TODO: attribute fileFormat: String
# TODO: attribute fileSize: Integer
# TODO: attribute uploadedAt: DateTime
# TODO: attribute storagePath: String
