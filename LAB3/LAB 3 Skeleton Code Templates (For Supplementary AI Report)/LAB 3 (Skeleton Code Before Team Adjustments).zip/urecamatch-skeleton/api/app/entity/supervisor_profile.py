# Purpose: SupervisorProfile <<entity>>, persistent data.
# TODO: attribute faculty: String
# TODO: attribute organisation: String
# TODO: association SupervisorProfile 1 -- 0..* ProjectListing (offers)
# TODO: association SupervisorProfile 1 -- 0..* Proposal (reviews)
