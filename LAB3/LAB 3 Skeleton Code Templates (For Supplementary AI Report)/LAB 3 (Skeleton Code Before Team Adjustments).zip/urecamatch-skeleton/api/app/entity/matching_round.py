# Purpose: MatchingRound <<entity>>, persistent data.
# TODO: attribute id: String
# TODO: attribute number: Integer
# TODO: attribute applicationStart: DateTime
# TODO: attribute applicationEnd: DateTime
# TODO: attribute reviewStart: DateTime
# TODO: attribute reviewEnd: DateTime
# TODO: attribute status: RoundStatus
# TODO: attribute executedAt: DateTime
# TODO: attribute publishedAt: DateTime
# TODO: association MatchingRound 1 -- 0..* MatchResult (produces)
