# Purpose: Proposal <<entity>>, persistent data.
# TODO: attribute id: String
# TODO: attribute title: String
# TODO: attribute description: String
# TODO: attribute researchInterests: List<String>
# TODO: attribute statement: String
# TODO: attribute status: ProposalStatus
# TODO: attribute submittedAt: DateTime
# TODO: attribute decidedAt: DateTime
# TODO: attribute documentIds: List<String>
# TODO: association Proposal 1 -- 0..1 ProjectListing (creates when accepted)
