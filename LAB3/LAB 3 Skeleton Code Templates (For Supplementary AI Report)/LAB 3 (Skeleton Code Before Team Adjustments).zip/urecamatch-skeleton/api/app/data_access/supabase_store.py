# Purpose: SupabaseStore, implements Store on Supabase PostgreSQL.
# TODO: implement every Store method
