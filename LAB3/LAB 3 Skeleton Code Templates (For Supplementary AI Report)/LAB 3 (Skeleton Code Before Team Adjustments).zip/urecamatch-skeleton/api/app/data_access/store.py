# Purpose: Store, interface (data access, Repository).
# TODO: user(id): User
# TODO: listing(id): ProjectListing
# TODO: saveListing(listing): ProjectListing
# TODO: applicationsFor(studentId, listingId, roundId): List<Application>
# TODO: saveApplications(apps): void
# TODO: ranking(listingId, roundId): List<String>
# TODO: saveNotifications(items): void
# TODO: one pair of read/save methods per entity
