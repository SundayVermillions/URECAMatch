# Purpose: MockStore, implements Store in memory.
# TODO: implement every Store method
