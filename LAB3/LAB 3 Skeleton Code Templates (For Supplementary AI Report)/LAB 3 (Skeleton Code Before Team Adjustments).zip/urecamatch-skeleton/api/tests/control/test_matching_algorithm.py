# Purpose: tests for MatchingAlgorithm.
# TODO: one test per operation of MatchingAlgorithm.
