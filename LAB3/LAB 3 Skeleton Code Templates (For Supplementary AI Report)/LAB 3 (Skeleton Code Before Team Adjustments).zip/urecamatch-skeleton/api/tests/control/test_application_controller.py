# Purpose: tests for ApplicationController.
# TODO: one test per operation of ApplicationController.
