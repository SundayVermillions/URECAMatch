# Purpose: tests for NotificationService.
# TODO: one test per operation of NotificationService.
