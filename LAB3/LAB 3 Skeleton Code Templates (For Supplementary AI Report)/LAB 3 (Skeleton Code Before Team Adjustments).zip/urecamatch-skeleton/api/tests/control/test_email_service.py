# Purpose: tests for EmailService.
# TODO: one test per operation of EmailService.
