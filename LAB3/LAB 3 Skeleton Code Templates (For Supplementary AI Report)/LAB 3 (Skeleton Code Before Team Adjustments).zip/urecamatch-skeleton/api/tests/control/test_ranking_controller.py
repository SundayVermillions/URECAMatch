# Purpose: tests for RankingController.
# TODO: one test per operation of RankingController.
