# Purpose: tests for UserAccountController.
# TODO: one test per operation of UserAccountController.
