# Purpose: tests for StorageService.
# TODO: one test per operation of StorageService.
