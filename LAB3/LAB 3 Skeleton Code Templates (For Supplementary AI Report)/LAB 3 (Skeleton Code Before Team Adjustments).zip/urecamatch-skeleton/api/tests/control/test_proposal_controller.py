# Purpose: tests for ProposalController.
# TODO: one test per operation of ProposalController.
