# Purpose: tests for AuditService.
# TODO: one test per operation of AuditService.
