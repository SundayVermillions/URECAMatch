# Purpose: tests for AuthController.
# TODO: one test per operation of AuthController.
