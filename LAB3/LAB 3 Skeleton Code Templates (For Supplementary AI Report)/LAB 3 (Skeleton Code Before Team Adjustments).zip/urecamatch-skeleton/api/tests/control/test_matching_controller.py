# Purpose: tests for MatchingController.
# TODO: one test per operation of MatchingController.
