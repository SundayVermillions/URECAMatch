# Purpose: tests for DashboardController.
# TODO: one test per operation of DashboardController.
