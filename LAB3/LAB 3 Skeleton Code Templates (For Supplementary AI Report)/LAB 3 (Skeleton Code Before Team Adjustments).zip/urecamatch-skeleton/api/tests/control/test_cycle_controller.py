# Purpose: tests for CycleController.
# TODO: one test per operation of CycleController.
