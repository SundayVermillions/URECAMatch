# Purpose: tests for ProfileController.
# TODO: one test per operation of ProfileController.
