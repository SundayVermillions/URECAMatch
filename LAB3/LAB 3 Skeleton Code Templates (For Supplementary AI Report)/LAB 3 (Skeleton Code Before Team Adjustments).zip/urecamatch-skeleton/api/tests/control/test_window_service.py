# Purpose: tests for WindowService.
# TODO: one test per operation of WindowService.
