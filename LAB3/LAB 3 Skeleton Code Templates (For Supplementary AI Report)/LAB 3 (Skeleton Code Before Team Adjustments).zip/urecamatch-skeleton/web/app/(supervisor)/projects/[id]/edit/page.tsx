// Purpose: EditProjectPage <<boundary>>, edit ProjectListing; ListingController.update.
// TODO: render the EditProjectPage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
