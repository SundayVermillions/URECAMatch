// Purpose: ApplicantAndRankingsPage <<boundary>>, applicants and ranking; RankingController.
// TODO: render the ApplicantAndRankingsPage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
