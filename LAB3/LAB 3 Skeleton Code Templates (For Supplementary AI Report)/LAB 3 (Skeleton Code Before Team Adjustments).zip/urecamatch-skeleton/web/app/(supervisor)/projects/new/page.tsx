// Purpose: CreateProjectPage <<boundary>>, new ProjectListing; ListingController.create / cover.
// TODO: render the CreateProjectPage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
