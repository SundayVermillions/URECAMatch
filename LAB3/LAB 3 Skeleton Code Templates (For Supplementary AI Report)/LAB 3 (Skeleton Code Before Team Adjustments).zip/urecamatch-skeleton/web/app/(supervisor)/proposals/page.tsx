// Purpose: StudentProposalsPage <<boundary>>, incoming Proposal list; ProposalController.incoming / accept / decline.
// TODO: render the StudentProposalsPage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
