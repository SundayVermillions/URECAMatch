// Purpose: MatchApprovalsPage <<boundary>>, proposed MatchResult list; MatchingController.approve / reject.
// TODO: render the MatchApprovalsPage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
