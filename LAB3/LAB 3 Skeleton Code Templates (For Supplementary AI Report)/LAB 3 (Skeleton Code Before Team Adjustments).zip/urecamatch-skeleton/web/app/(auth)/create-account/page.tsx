// Purpose: CreateAccountPage <<boundary>>, registration form with role choice; calls AuthController.register.
// TODO: render the CreateAccountPage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
