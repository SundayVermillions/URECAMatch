// Purpose: SignInPage <<boundary>>, sign-in form; calls ApiClient.signIn(email, password).
// TODO: render the SignInPage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
