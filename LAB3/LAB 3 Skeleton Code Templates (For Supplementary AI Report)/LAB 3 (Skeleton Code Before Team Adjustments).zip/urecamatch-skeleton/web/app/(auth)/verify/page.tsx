// Purpose: EmailVerificationPage <<boundary>>, 6-digit code entry and resend; calls AuthController.verify / resend.
// TODO: render the EmailVerificationPage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
