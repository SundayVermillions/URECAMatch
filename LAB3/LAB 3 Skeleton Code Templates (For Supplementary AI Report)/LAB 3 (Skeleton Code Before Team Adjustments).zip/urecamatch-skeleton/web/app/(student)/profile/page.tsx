// Purpose: MyProfilePage <<boundary>>, view and edit StudentProfile, upload SupportingDocument.
// TODO: render the MyProfilePage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
