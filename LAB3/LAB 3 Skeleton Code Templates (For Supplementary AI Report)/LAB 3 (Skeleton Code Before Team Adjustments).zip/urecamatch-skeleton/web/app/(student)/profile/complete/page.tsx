// Purpose: CompleteProfilePage <<boundary>>, first-time profile form; ProfileController.updateProfile.
// TODO: render the CompleteProfilePage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
