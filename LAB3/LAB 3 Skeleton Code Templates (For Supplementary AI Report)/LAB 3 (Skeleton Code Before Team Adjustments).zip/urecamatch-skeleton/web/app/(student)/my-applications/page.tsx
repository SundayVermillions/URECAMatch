// Purpose: MyApplicationPage <<boundary>>, applications, ranking, proposals and the match offer; ApplicationController, MatchingController.acceptOffer / declineOffer.
// TODO: render the MyApplicationPage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
