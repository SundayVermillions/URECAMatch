// Purpose: ProposeProjectPage <<boundary>>, self-proposal form and supervisor picker; ProposalController.propose.
// TODO: render the ProposeProjectPage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
