// Purpose: ApplyProjectPage <<boundary>>, statement and documents; ApplicationController.apply.
// TODO: render the ApplyProjectPage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
