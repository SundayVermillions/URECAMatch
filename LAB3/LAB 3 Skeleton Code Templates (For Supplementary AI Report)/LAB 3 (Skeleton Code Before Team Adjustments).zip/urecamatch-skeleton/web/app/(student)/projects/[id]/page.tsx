// Purpose: ProjectDetailPage <<boundary>>, one ProjectListing; ListingController.detail.
// TODO: render the ProjectDetailPage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
