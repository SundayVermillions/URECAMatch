// Purpose: BrowseProjectPage <<boundary>>, search and filter ProjectListing; ListingController.browse.
// TODO: render the BrowseProjectPage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
