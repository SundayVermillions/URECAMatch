// Purpose: AdminDashboardPage <<boundary>>, counts and alerts; DashboardController.adminDashboard.
// TODO: render the AdminDashboardPage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
