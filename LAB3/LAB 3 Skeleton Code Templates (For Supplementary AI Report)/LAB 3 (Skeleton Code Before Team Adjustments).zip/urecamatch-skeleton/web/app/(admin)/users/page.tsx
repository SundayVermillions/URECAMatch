// Purpose: ManageUsersPage <<boundary>>, user list; UserAccountController.
// TODO: render the ManageUsersPage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
