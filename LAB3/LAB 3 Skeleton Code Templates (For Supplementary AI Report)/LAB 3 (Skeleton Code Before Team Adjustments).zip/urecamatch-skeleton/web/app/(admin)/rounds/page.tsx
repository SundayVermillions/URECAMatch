// Purpose: MatchingRoundsPage <<boundary>>, cycle and rounds; CycleController, MatchingController.execute.
// TODO: render the MatchingRoundsPage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
