// Purpose: NotificationPage <<boundary>>, own notifications, newest first; DashboardController.myNotifications / markRead.
// TODO: render the NotificationPage screen as specified in the dialog map.
// TODO: call the API only through ApiClient (web/lib/api).
