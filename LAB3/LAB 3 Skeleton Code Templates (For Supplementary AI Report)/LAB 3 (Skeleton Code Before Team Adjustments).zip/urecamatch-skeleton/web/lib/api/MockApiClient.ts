// Purpose: MockApiClient, implements ApiClient on in-browser seed data.
// TODO: implement every ApiClient method
