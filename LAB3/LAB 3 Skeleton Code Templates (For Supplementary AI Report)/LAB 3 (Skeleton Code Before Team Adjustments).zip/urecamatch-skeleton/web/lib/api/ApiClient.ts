// Purpose: ApiClient, <<boundary>> interface.
// TODO: signIn(email, password): Session
// TODO: browse(filters): List<Listing>
// TODO: apply(listingId, statement, documentIds): Application
// TODO: execute(roundId): RoundSummary
// TODO: one method per API endpoint
