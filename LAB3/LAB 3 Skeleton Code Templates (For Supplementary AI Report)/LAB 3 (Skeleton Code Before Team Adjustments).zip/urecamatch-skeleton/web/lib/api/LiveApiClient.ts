// Purpose: LiveApiClient, implements ApiClient over HTTPS / REST.
// TODO: implement every ApiClient method
