<!-- Purpose: URECAMatch project skeleton generated from the Lab 3 design class diagram. -->
<!-- TODO: describe how to run the web client (web/) and the API server (api/). -->
<!-- TODO: explain the folder-to-stereotype mapping: web/app = boundary, api/app/control = control, -->
<!--       api/app/entity = entity, api/app/data_access = data access (Store). -->
